import { Button, Space } from "antd-mobile";
import "./index.scss";
import MapComponent from "src/components/Map";

function Map() {
  return (
    <div id="map">
      
      <MapComponent />
    </div>
  );
}

export default Map;
