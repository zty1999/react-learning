function News() {
  return <p>jsjrgpradfdsf </p>;
}

export default News;
