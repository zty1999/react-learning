import * as actionTypes from "../../constants";

// export const nameAction = (name): nameProps => ({
//   type: actionTypes.CHANGE_NAME, name
// })
export const nameAction = {
  type: actionTypes.CHANGE_NAME, name: 'test2'
}