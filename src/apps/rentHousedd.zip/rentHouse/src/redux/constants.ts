export const ADD_COUNTER = 'add_counter';
export const CHANGE_NAME = 'change_name';